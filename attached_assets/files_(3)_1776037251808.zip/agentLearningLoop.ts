/**
 * server/operator/agentLearningLoop.ts
 *
 * Periodic learning loop — runs every 6 hours.
 * Reads accumulated intelligence signals, detects repeatable cross-agent
 * patterns, and writes distilled learnings to episodic memory.
 *
 * QUALITY GATES (nothing below these thresholds writes to memory):
 *   - Minimum occurrences: 3
 *   - Minimum confidence:  0.65
 *
 * MULTI-TENANT SAFETY:
 *   - Account-scoped patterns are written to that account's episodic memory only.
 *   - Global patterns (subAccountId: null) are NOT written to agentMemories —
 *     the FK constraint requires a valid subAccountId. Global patterns remain
 *     in intelligence_signals and are visible only via the admin endpoint.
 *
 * EPISODIC MEMORY:
 *   - Uses the real recordEpisodicMemory() signature from episodicMemory.ts.
 *   - memoryType is cast to "apex_learning" — a TypeScript-only extension of
 *     EpisodicMemoryType. The agentMemories table uses text(), so this is safe.
 *   - source is always tagged "apex-intelligence".
 *   - decayRate is 0.002 (slow) — structural patterns persist longer.
 */

import { getRecentSignals }    from "./intelligenceAggregator";
import { recordEpisodicMemory } from "./episodicMemory";
import type { EpisodicMemoryType } from "./cognitiveTypes";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const LOOP_INTERVAL_MS   = 6 * 60 * 60 * 1000;  // 6 hours
const MIN_OCCURRENCES    = 3;
const MIN_CONFIDENCE     = 0.65;
const ANALYSIS_WINDOW_MS = 48 * 60 * 60 * 1000; // 48-hour lookback
const PATTERN_WINDOW_MS  = 30 * 60 * 1000;       // 30-min co-occurrence window

let loopTimer: ReturnType<typeof setInterval> | null = null;

// ---------------------------------------------------------------------------
// Pattern detection — pure function, no I/O
// ---------------------------------------------------------------------------

interface DetectedPattern {
  key:          string;
  agentA:       string;
  actionA:      string;
  agentB:       string;
  actionB:      string;
  occurrences:  number;
  confidence:   number;
  subAccountId: number | null; // null = global
  examples:     string[];
}

function detectPatterns(
  signals: Array<{
    agentName:    string;
    action:       string;
    result:       string;
    subAccountId: number | null;
    createdAt:    string;
    confidence:   number;
  }>,
): DetectedPattern[] {
  const pairCounts = new Map<string, DetectedPattern>();

  // Sort chronologically so pairs are always (earlier, later)
  const sorted = [...signals].sort(
    (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime(),
  );

  for (let i = 0; i < sorted.length; i++) {
    const a = sorted[i];

    for (let j = i + 1; j < sorted.length; j++) {
      const b = sorted[j];

      const tA = new Date(a.createdAt).getTime();
      const tB = new Date(b.createdAt).getTime();

      // Only consider events within the co-occurrence window
      if (tB - tA > PATTERN_WINDOW_MS) break;

      // Cross-agent only
      if (a.agentName === b.agentName) continue;

      // Same scope: both from same account, or both global
      // Never mix account-scoped and global signals into one pattern
      if (a.subAccountId !== b.subAccountId) continue;

      const key = [
        a.agentName, ":", a.action,
        "→",
        b.agentName, ":", b.action,
        ":scope:", String(a.subAccountId ?? "global"),
      ].join("");

      const existing = pairCounts.get(key) ?? {
        key,
        agentA:       a.agentName,
        actionA:      a.action,
        agentB:       b.agentName,
        actionB:      b.action,
        occurrences:  0,
        confidence:   0,
        subAccountId: a.subAccountId,
        examples:     [],
      };

      existing.occurrences++;

      // Rolling average confidence of contributing signal pairs
      existing.confidence =
        (existing.confidence * (existing.occurrences - 1) +
          (a.confidence + b.confidence) / 2) /
        existing.occurrences;

      if (existing.examples.length < 3) {
        existing.examples.push(
          `${a.result.substring(0, 50)} → ${b.result.substring(0, 50)}`,
        );
      }

      pairCounts.set(key, existing);
    }
  }

  return Array.from(pairCounts.values())
    .filter(p => p.occurrences >= MIN_OCCURRENCES && p.confidence >= MIN_CONFIDENCE)
    .sort((a, b) => b.occurrences - a.occurrences);
}

// ---------------------------------------------------------------------------
// Learning cycle — I/O, runs on schedule
// ---------------------------------------------------------------------------

async function runLearningCycle(): Promise<void> {
  console.log("[APEX-LEARNING] Starting learning cycle...");

  try {
    const since   = new Date(Date.now() - ANALYSIS_WINDOW_MS);
    const signals = await getRecentSignals({ since, limit: 500 });

    if (signals.length < MIN_OCCURRENCES * 2) {
      console.log(
        `[APEX-LEARNING] Insufficient signals (${signals.length}) — skipping cycle`,
      );
      return;
    }

    const patterns = detectPatterns(signals);
    console.log(
      `[APEX-LEARNING] ${patterns.length} qualifying pattern(s) from ${signals.length} signal(s)`,
    );

    let memoriesWritten = 0;
    let globalSkipped   = 0;

    for (const pattern of patterns) {
      // Global patterns: FK constraint prevents writing to agentMemories with null subAccountId.
      // These patterns are captured in intelligence_signals and visible via admin endpoint.
      if (pattern.subAccountId === null) {
        globalSkipped++;
        continue;
      }

      const content = [
        `Cross-agent pattern: When ${pattern.agentA} performs "${pattern.actionA}", `,
        `${pattern.agentB} consistently follows with "${pattern.actionB}" `,
        `(${pattern.occurrences} occurrences, ${Math.round(pattern.confidence * 100)}% confidence). `,
        pattern.examples.length > 0
          ? `Examples: ${pattern.examples.slice(0, 2).join("; ")}`
          : "",
      ].join("").trim();

      // Cast to EpisodicMemoryType — "apex_learning" is a TypeScript-only
      // extension; the agentMemories table stores it as text, so this is safe.
      const memoryType = "apex_learning" as EpisodicMemoryType;

      await recordEpisodicMemory({
        subAccountId:  pattern.subAccountId,
        memoryType,
        content,
        category:      "cross_agent_pattern",
        relevanceScore: Math.min(0.95, 0.5 + pattern.occurrences * 0.05),
        decayRate:     0.002, // slow decay — structural patterns are stable
        sourceEvent:   "apex-intelligence",
        sourceContext: {
          agentA:       pattern.agentA,
          actionA:      pattern.actionA,
          agentB:       pattern.agentB,
          actionB:      pattern.actionB,
          occurrences:  pattern.occurrences,
          confidence:   pattern.confidence,
        },
        outcome: "pattern_detected",
        tags:    [
          "apex-intelligence",
          "cross-agent-pattern",
          pattern.agentA,
          pattern.agentB,
        ],
      });

      memoriesWritten++;
    }

    console.log(
      `[APEX-LEARNING] Cycle complete — ${memoriesWritten} memories written` +
      (globalSkipped > 0 ? `, ${globalSkipped} global patterns retained in signals table` : ""),
    );
  } catch (err: any) {
    console.error("[APEX-LEARNING] Cycle failed:", err?.message);
  }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function startLearningLoop(): void {
  console.log("[APEX-LEARNING] Learning loop started — runs every 6 hours");

  // Delay first run by 60s to let server fully initialize
  setTimeout(() => runLearningCycle(), 60_000);

  loopTimer = setInterval(() => runLearningCycle(), LOOP_INTERVAL_MS);
}

export function stopLearningLoop(): void {
  if (loopTimer) {
    clearInterval(loopTimer);
    loopTimer = null;
  }
  console.log("[APEX-LEARNING] Stopped");
}
