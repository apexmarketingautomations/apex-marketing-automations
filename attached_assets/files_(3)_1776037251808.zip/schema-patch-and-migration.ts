// ============================================================
// PATCH: shared/schema.ts
// Add this block after the agentMemories table definition.
// Follows the exact same pattern as all other tables in this file.
// ============================================================

// ---- Apex Intelligence Signals ----
// Stores normalized outcome signals from all contributing agents.
// subAccountId is nullable: null = global/system-level signal, number = account-scoped.
// Global signals are visible only via the admin /api/intelligence/apex endpoint.

export const intelligenceSignals = pgTable("intelligence_signals", {
  id:           serial("id").primaryKey(),
  agentName:    text("agent_name").notNull(),
  action:       text("action").notNull(),
  subject:      text("subject"),
  result:       text("result").notNull(),
  confidence:   real("confidence").default(0.5),
  subAccountId: integer("sub_account_id").references(() => subAccounts.id),  // nullable
  metadata:     json("metadata"),
  createdAt:    timestamp("created_at").defaultNow().notNull(),
});

export const insertIntelligenceSignalSchema = createInsertSchema(intelligenceSignals).omit({
  id:        true,
  createdAt: true,
});
export type InsertIntelligenceSignal = z.infer<typeof insertIntelligenceSignalSchema>;
export type IntelligenceSignal       = typeof intelligenceSignals.$inferSelect;


// ============================================================
// MIGRATION SQL
// Run this against the real database before deploying.
// ============================================================

/*

CREATE TABLE IF NOT EXISTS intelligence_signals (
  id            SERIAL PRIMARY KEY,
  agent_name    TEXT    NOT NULL,
  action        TEXT    NOT NULL,
  subject       TEXT,
  result        TEXT    NOT NULL,
  confidence    REAL    DEFAULT 0.5,
  sub_account_id INTEGER REFERENCES sub_accounts(id) ON DELETE SET NULL,
  metadata      JSON,
  created_at    TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Index for account-scoped queries (context builder, aggregator)
CREATE INDEX idx_intelligence_signals_account_time
  ON intelligence_signals (sub_account_id, created_at DESC)
  WHERE sub_account_id IS NOT NULL;

-- Index for global signal queries and admin stats
CREATE INDEX idx_intelligence_signals_time
  ON intelligence_signals (created_at DESC);

-- Index for agent-level rate limit and stats queries
CREATE INDEX idx_intelligence_signals_agent
  ON intelligence_signals (agent_name, created_at DESC);

-- Verify migration:
SELECT COUNT(*) FROM intelligence_signals;   -- must return 0 on fresh install, not error

*/
