/**
 * server/operator/intelligenceAggregator.ts
 *
 * Receives normalized outcome signals, deduplicates them, rate-limits per agent,
 * stores to intelligence_signals, and provides read models.
 *
 * MULTI-TENANT SAFETY:
 *   - subAccountId: null  = global/system signal, never served to account contexts
 *   - subAccountId: number = account-scoped, only returned when that account is queried
 *   - getRecentSignals() enforces account isolation at the DB WHERE clause level
 *
 * RATE LIMITS (in-memory, resets on server restart):
 *   - 100 signals per agent per hour
 *
 * DEDUP WINDOW:
 *   - 5 minutes: same agentName + action + result combination is dropped
 */

import { db } from "../db";
import { intelligenceSignals } from "@shared/schema";
import { eq, desc, gte, and, isNull } from "drizzle-orm";
import crypto from "crypto";

// ---------------------------------------------------------------------------
// Rate limiting — per agent, in-memory sliding window
// ---------------------------------------------------------------------------

const RATE_LIMIT_WINDOW_MS = 60 * 60 * 1000; // 1 hour
const RATE_LIMIT_MAX        = 100;

const rateLimitBuckets = new Map<string, { count: number; windowStart: number }>();

function checkRateLimit(agentName: string): boolean {
  const now    = Date.now();
  const bucket = rateLimitBuckets.get(agentName);

  if (!bucket || now - bucket.windowStart > RATE_LIMIT_WINDOW_MS) {
    rateLimitBuckets.set(agentName, { count: 1, windowStart: now });
    return true;
  }

  if (bucket.count >= RATE_LIMIT_MAX) {
    console.warn(`[APEX-AGGREGATOR] Rate limit reached for agent "${agentName}" — signal dropped`);
    return false;
  }

  bucket.count++;
  return true;
}

// ---------------------------------------------------------------------------
// Dedup — in-memory, 5-minute window per agentName+action+result hash
// ---------------------------------------------------------------------------

const DEDUP_WINDOW_MS = 5 * 60 * 1000;
const dedupCache      = new Map<string, number>(); // hash → last-seen timestamp

function isDuplicate(agentName: string, action: string, result: string): boolean {
  const hash = crypto
    .createHash("sha256")
    .update(`${agentName}|${action}|${result}`)
    .digest("hex")
    .substring(0, 32);

  const now      = Date.now();
  const lastSeen = dedupCache.get(hash);

  if (lastSeen && now - lastSeen < DEDUP_WINDOW_MS) return true;

  dedupCache.set(hash, now);

  // Prune stale entries to bound memory
  if (dedupCache.size > 1000) {
    for (const [k, v] of dedupCache.entries()) {
      if (now - v > DEDUP_WINDOW_MS) dedupCache.delete(k);
    }
  }

  return false;
}

// ---------------------------------------------------------------------------
// Signal input type
// ---------------------------------------------------------------------------

export interface SignalInput {
  agentName:    string;
  action:       string;
  subject:      string | null;
  result:       string;
  confidence:   number;
  subAccountId: number | null;
  metadata:     Record<string, any> | null;
}

// ---------------------------------------------------------------------------
// Write path
// ---------------------------------------------------------------------------

export async function reportSignal(input: SignalInput): Promise<void> {
  if (isDuplicate(input.agentName, input.action, input.result)) return;
  if (!checkRateLimit(input.agentName)) return;

  await db.insert(intelligenceSignals).values({
    agentName:    input.agentName,
    action:       input.action,
    subject:      input.subject,
    result:       input.result,
    confidence:   input.confidence,
    subAccountId: input.subAccountId,
    metadata:     input.metadata,
  });
}

// ---------------------------------------------------------------------------
// Read models
// ---------------------------------------------------------------------------

export interface SignalRecord {
  id:           number;
  agentName:    string;
  action:       string;
  subject:      string | null;
  result:       string;
  confidence:   number;
  subAccountId: number | null;
  metadata:     unknown;
  createdAt:    string;
}

export async function getRecentSignals(options: {
  subAccountId?: number;   // if set: returns only this account's signals (never cross-account)
  globalOnly?:   boolean;  // if true: returns only null-subAccountId global signals
  limit?:        number;
  since?:        Date;
} = {}): Promise<SignalRecord[]> {
  const { subAccountId, globalOnly, limit = 50, since } = options;

  const conditions: ReturnType<typeof eq>[] = [];

  if (globalOnly) {
    conditions.push(isNull(intelligenceSignals.subAccountId) as any);
  } else if (subAccountId !== undefined) {
    conditions.push(eq(intelligenceSignals.subAccountId, subAccountId) as any);
  }

  if (since) {
    conditions.push(gte(intelligenceSignals.createdAt, since) as any);
  }

  const rows = await db
    .select()
    .from(intelligenceSignals)
    .where(conditions.length > 0 ? and(...conditions as any) : undefined)
    .orderBy(desc(intelligenceSignals.createdAt))
    .limit(limit);

  return rows.map(r => ({
    id:           r.id,
    agentName:    r.agentName,
    action:       r.action,
    subject:      r.subject ?? null,
    result:       r.result,
    confidence:   r.confidence ?? 0.5,
    subAccountId: r.subAccountId ?? null,
    metadata:     r.metadata,
    createdAt:    r.createdAt.toISOString(),
  }));
}

export interface SignalStats {
  totalSignals:   number;
  last24h:        number;
  byAgent:        Array<{ agentName: string; count: number; lastSeen: string }>;
  globalSignals:  number;
  accountSignals: number;
}

export async function getSignalStats(): Promise<SignalStats> {
  try {
    const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000);

    // Cap at 1000 rows — sufficient for admin stats, safe for performance
    const all = await db
      .select()
      .from(intelligenceSignals)
      .orderBy(desc(intelligenceSignals.createdAt))
      .limit(1000);

    const last24hCount = all.filter(r => r.createdAt >= since24h).length;

    const agentMap = new Map<string, { count: number; lastSeen: string }>();
    for (const row of all) {
      const existing = agentMap.get(row.agentName) ?? {
        count:    0,
        lastSeen: row.createdAt.toISOString(),
      };
      existing.count++;
      const rowIso = row.createdAt.toISOString();
      if (rowIso > existing.lastSeen) existing.lastSeen = rowIso;
      agentMap.set(row.agentName, existing);
    }

    const globalSignals = all.filter(r => r.subAccountId === null).length;

    return {
      totalSignals:   all.length,
      last24h:        last24hCount,
      byAgent:        Array.from(agentMap.entries())
                        .map(([agentName, d]) => ({ agentName, count: d.count, lastSeen: d.lastSeen }))
                        .sort((a, b) => b.count - a.count),
      globalSignals,
      accountSignals: all.length - globalSignals,
    };
  } catch (err: any) {
    console.error("[APEX-AGGREGATOR] getSignalStats failed:", err?.message);
    return {
      totalSignals: 0, last24h: 0, byAgent: [], globalSignals: 0, accountSignals: 0,
    };
  }
}
