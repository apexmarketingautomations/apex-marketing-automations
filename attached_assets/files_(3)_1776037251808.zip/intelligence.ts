// server/routes/intelligence.ts
// Modified: added GET /api/intelligence/apex inside registerIntelligenceRoutes().
// Uses the same requireAdmin pattern as all adjacent routes.
// All existing routes are unchanged.

import type { Express, Request, Response } from "express";
import { getTopSharedInsights, getInsightStats, archiveStaleInsights, refreshInsightsFromRecentConversations } from "../sharedIntelligence";

function requireAdmin(req: Request, res: Response): boolean {
  const secret = process.env.ADMIN_API_SECRET || process.env.ADMIN_USER_ID;
  if (!secret) {
    res.status(503).json({ error: "Admin API not configured" });
    return false;
  }
  const auth = req.headers["x-admin-secret"];
  if (auth !== secret) {
    res.status(403).json({ error: "Forbidden" });
    return false;
  }
  return true;
}

export function registerIntelligenceRoutes(app: Express) {
  app.get("/api/intelligence/insights", async (req: Request, res: Response) => {
    if (!requireAdmin(req, res)) return;
    try {
      const category = req.query.category as string | undefined;
      const limitParam = parseInt(req.query.limit as string) || 20;
      const limit = Math.min(limitParam, 100);
      const minConfidence = parseFloat(req.query.minConfidence as string) || 0.05;
      const [insights, stats] = await Promise.all([
        getTopSharedInsights({ limit, category, minConfidence }),
        getInsightStats(),
      ]);
      res.json({
        insights,
        stats,
        generatedAt: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/intelligence/insights/refresh", async (req: Request, res: Response) => {
    if (!requireAdmin(req, res)) return;
    try {
      const { subAccountId = 13, limitConversations = 20 } = req.body || {};
      const accountIds = Array.isArray(subAccountId) ? subAccountId : [subAccountId];
      let totalExtracted = 0;
      for (const acctId of accountIds) {
        const count = await refreshInsightsFromRecentConversations(acctId, limitConversations);
        totalExtracted += count;
      }
      const archived = await archiveStaleInsights();
      res.json({
        message: "Refresh complete",
        accountsProcessed: accountIds.length,
        conversationsAnalyzed: totalExtracted,
        staleInsightsArchived: archived,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/intelligence/insights/cleanup", async (req: Request, res: Response) => {
    if (!requireAdmin(req, res)) return;
    try {
      const archived = await archiveStaleInsights();
      res.json({ archivedCount: archived });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ---------------------------------------------------------------------------
  // NEW: Apex Intelligence unified state
  //
  // Admin-only. Returns cross-agent orchestrator state: registry, signal stats,
  // recent signals (last 24h). Never exposes raw customer data — signals are
  // summarized outcomes, not message content.
  //
  // Auth: same requireAdmin pattern as all routes above.
  // Do NOT change this to verifyAccountOwnership — this endpoint is
  // intentionally cross-account and admin-level.
  // ---------------------------------------------------------------------------
  app.get("/api/intelligence/apex", async (req: Request, res: Response) => {
    if (!requireAdmin(req, res)) return;
    try {
      const { getApexState } = await import("../operator/apexIntelligence");
      const state = await getApexState();
      res.json(state);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });
}
