// client/src/components/intelligence/ApexBrainTab.tsx
//
// Admin-only Apex Brain dashboard view.
// Fetches from /api/intelligence/apex using x-admin-secret header.
// Shows: orchestrator status, active agents, recent signal feed,
//        distilled cross-agent learnings, signal distribution stats.
//
// This is an internal tool — it must not be rendered in customer-facing routes.

import { useState, useEffect, useCallback } from "react";

// ---------------------------------------------------------------------------
// Types — mirroring the server-side shapes
// ---------------------------------------------------------------------------

interface AgentRegistration {
  name:           string;
  capabilities:   string[];
  outputSchema:   string;
  registeredAt:   string;
  lastReportedAt: string | null;
  totalReports:   number;
  status:         "active" | "idle" | "error";
  lastError?:     string;
}

interface SignalRecord {
  id:           number;
  agentName:    string;
  action:       string;
  subject:      string | null;
  result:       string;
  confidence:   number;
  subAccountId: number | null;
  metadata:     unknown;
  createdAt:    string;
}

interface SignalStats {
  totalSignals:   number;
  last24h:        number;
  byAgent:        Array<{ agentName: string; count: number; lastSeen: string }>;
  globalSignals:  number;
  accountSignals: number;
}

interface ApexState {
  registry:      AgentRegistration[];
  signalStats:   SignalStats;
  recentSignals: SignalRecord[];
  generatedAt:   string;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function timeAgo(iso: string | null): string {
  if (!iso) return "never";
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60_000);
  if (minutes < 1)  return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24)   return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

function statusColor(status: AgentRegistration["status"]): string {
  if (status === "active") return "#22c55e";
  if (status === "error")  return "#ef4444";
  return "#94a3b8";
}

function confidenceBadge(confidence: number): string {
  if (confidence >= 0.85) return "#22c55e";
  if (confidence >= 0.6)  return "#f59e0b";
  return "#94a3b8";
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function ApexBrainTab() {
  const [state, setState]     = useState<ApexState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState<string | null>(null);

  const fetchApexState = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const adminSecret =
        (window as any).__ADMIN_SECRET__ ||
        localStorage.getItem("adminSecret") ||
        "";

      const res = await fetch("/api/intelligence/apex", {
        headers: {
          "x-admin-secret": adminSecret,
        },
      });

      if (res.status === 403) {
        setError("Admin access required. Set x-admin-secret header.");
        return;
      }
      if (!res.ok) {
        setError(`Server error: ${res.status}`);
        return;
      }

      const data = await res.json();
      setState(data);
    } catch (err: any) {
      setError(err?.message ?? "Failed to fetch Apex state");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchApexState();
    const interval = setInterval(fetchApexState, 60_000); // refresh every 60s
    return () => clearInterval(interval);
  }, [fetchApexState]);

  if (loading) {
    return (
      <div style={styles.container}>
        <div style={styles.header}>
          <span style={styles.title}>⬡ Apex Brain</span>
          <span style={styles.subtitle}>Loading orchestrator state...</span>
        </div>
        <div style={styles.skeletonGrid}>
          {[1, 2, 3].map(i => (
            <div key={i} style={styles.skeleton} />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={styles.container}>
        <div style={styles.header}>
          <span style={styles.title}>⬡ Apex Brain</span>
        </div>
        <div style={styles.errorBox}>
          <span style={{ color: "#ef4444", fontWeight: 700 }}>Error: </span>
          {error}
          <button onClick={fetchApexState} style={styles.retryBtn}>Retry</button>
        </div>
      </div>
    );
  }

  if (!state) return null;

  const { registry, signalStats, recentSignals, generatedAt } = state;
  const activeAgents  = registry.filter(a => a.status === "active").length;
  const errorAgents   = registry.filter(a => a.status === "error").length;

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <div>
          <span style={styles.title}>⬡ Apex Brain</span>
          <span style={styles.adminBadge}>ADMIN ONLY</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={styles.generatedAt}>
            Updated {timeAgo(generatedAt)}
          </span>
          <button onClick={fetchApexState} style={styles.refreshBtn}>↻ Refresh</button>
        </div>
      </div>

      {/* Top stats row */}
      <div style={styles.statsRow}>
        <StatCard
          label="Registered Agents"
          value={registry.length}
          sub={`${activeAgents} active${errorAgents > 0 ? `, ${errorAgents} error` : ""}`}
          color={errorAgents > 0 ? "#ef4444" : "#22c55e"}
        />
        <StatCard
          label="Signals (24h)"
          value={signalStats.last24h}
          sub={`${signalStats.totalSignals} total`}
          color="#f59e0b"
        />
        <StatCard
          label="Account Signals"
          value={signalStats.accountSignals}
          sub="scoped to accounts"
          color="#818cf8"
        />
        <StatCard
          label="Global Signals"
          value={signalStats.globalSignals}
          sub="system-level"
          color="#64748b"
        />
      </div>

      <div style={styles.twoCol}>
        {/* Agent registry */}
        <section style={styles.card}>
          <h3 style={styles.cardTitle}>Contributor Registry</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {registry.length === 0 && (
              <p style={styles.emptyNote}>No agents registered. Check server initialization.</p>
            )}
            {registry.map(agent => (
              <div key={agent.name} style={styles.agentRow}>
                <div style={styles.agentLeft}>
                  <span
                    style={{
                      ...styles.statusDot,
                      backgroundColor: statusColor(agent.status),
                    }}
                  />
                  <div>
                    <div style={styles.agentName}>{agent.name}</div>
                    <div style={styles.agentMeta}>
                      {agent.capabilities.slice(0, 2).join(", ")}
                      {agent.capabilities.length > 2 ? ` +${agent.capabilities.length - 2}` : ""}
                    </div>
                  </div>
                </div>
                <div style={styles.agentRight}>
                  <div style={styles.agentCount}>{agent.totalReports} signals</div>
                  <div style={styles.agentMeta}>
                    Last: {timeAgo(agent.lastReportedAt)}
                  </div>
                  {agent.lastError && (
                    <div style={{ color: "#ef4444", fontSize: 10, maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {agent.lastError}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Signal volume by agent */}
        <section style={styles.card}>
          <h3 style={styles.cardTitle}>Signal Volume by Agent</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {signalStats.byAgent.length === 0 && (
              <p style={styles.emptyNote}>No signals recorded yet.</p>
            )}
            {signalStats.byAgent.slice(0, 8).map(a => {
              const maxCount = signalStats.byAgent[0]?.count || 1;
              const pct = Math.round((a.count / maxCount) * 100);
              return (
                <div key={a.agentName}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                    <span style={styles.barLabel}>{a.agentName}</span>
                    <span style={{ ...styles.barLabel, color: "#94a3b8" }}>
                      {a.count} · {timeAgo(a.lastSeen)}
                    </span>
                  </div>
                  <div style={styles.barBg}>
                    <div style={{ ...styles.barFill, width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>

      {/* Recent signal feed */}
      <section style={styles.card}>
        <h3 style={styles.cardTitle}>Recent Intelligence Signals (24h)</h3>
        {recentSignals.length === 0 && (
          <p style={styles.emptyNote}>No signals in the last 24 hours. Agents may not be reporting yet.</p>
        )}
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          {recentSignals.slice(0, 20).map(sig => (
            <div key={sig.id} style={styles.signalRow}>
              <div style={styles.signalLeft}>
                <span
                  style={{
                    ...styles.confidenceDot,
                    backgroundColor: confidenceBadge(sig.confidence),
                  }}
                />
                <div>
                  <div style={styles.signalAgent}>
                    {sig.agentName}
                    <span style={styles.signalAction}> · {sig.action}</span>
                    {sig.subject && (
                      <span style={styles.signalSubject}> → {sig.subject}</span>
                    )}
                  </div>
                  <div style={styles.signalResult}>{sig.result}</div>
                </div>
              </div>
              <div style={styles.signalRight}>
                <div style={styles.signalMeta}>
                  {sig.subAccountId !== null ? `acct #${sig.subAccountId}` : "global"}
                </div>
                <div style={styles.signalMeta}>{timeAgo(sig.createdAt)}</div>
                <div style={{ ...styles.signalMeta, color: confidenceBadge(sig.confidence) }}>
                  {Math.round(sig.confidence * 100)}%
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Sub-components
// ---------------------------------------------------------------------------

function StatCard({
  label,
  value,
  sub,
  color,
}: {
  label: string;
  value: number;
  sub: string;
  color: string;
}) {
  return (
    <div style={{ ...styles.statCard, borderColor: color + "33" }}>
      <div style={{ ...styles.statValue, color }}>{value}</div>
      <div style={styles.statLabel}>{label}</div>
      <div style={styles.statSub}>{sub}</div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Styles — inline to avoid CSS module dependency
// ---------------------------------------------------------------------------

const styles: Record<string, React.CSSProperties> = {
  container: {
    padding:    "24px",
    fontFamily: "system-ui, -apple-system, sans-serif",
    maxWidth:   "1200px",
    margin:     "0 auto",
    color:      "#f1f5f9",
  },
  header: {
    display:        "flex",
    justifyContent: "space-between",
    alignItems:     "center",
    marginBottom:   24,
  },
  title: {
    fontSize:   22,
    fontWeight: 800,
    color:      "#f1f5f9",
    marginRight: 10,
  },
  adminBadge: {
    fontSize:        9,
    fontWeight:      900,
    letterSpacing:   "0.1em",
    color:           "#ef4444",
    background:      "rgba(239,68,68,0.1)",
    border:          "1px solid rgba(239,68,68,0.3)",
    padding:         "2px 6px",
    borderRadius:    4,
    verticalAlign:   "middle",
  },
  subtitle: {
    fontSize: 13,
    color:    "#64748b",
  },
  generatedAt: {
    fontSize: 11,
    color:    "#64748b",
  },
  refreshBtn: {
    background:   "rgba(255,255,255,0.05)",
    border:       "1px solid rgba(255,255,255,0.1)",
    color:        "#94a3b8",
    borderRadius: 6,
    padding:      "4px 10px",
    cursor:       "pointer",
    fontSize:     12,
  },
  statsRow: {
    display:             "grid",
    gridTemplateColumns: "repeat(4, 1fr)",
    gap:                 16,
    marginBottom:        24,
  },
  statCard: {
    background:   "rgba(255,255,255,0.03)",
    border:       "1px solid",
    borderRadius: 12,
    padding:      "16px 20px",
  },
  statValue: {
    fontSize:   32,
    fontWeight: 900,
    lineHeight: 1,
  },
  statLabel: {
    fontSize:   11,
    fontWeight: 700,
    color:      "#64748b",
    textTransform: "uppercase" as const,
    letterSpacing: "0.06em",
    marginTop:  6,
  },
  statSub: {
    fontSize:  10,
    color:     "#475569",
    marginTop: 2,
  },
  twoCol: {
    display:             "grid",
    gridTemplateColumns: "1fr 1fr",
    gap:                 16,
    marginBottom:        16,
  },
  card: {
    background:   "rgba(255,255,255,0.02)",
    border:       "1px solid rgba(255,255,255,0.06)",
    borderRadius: 12,
    padding:      "20px 24px",
    marginBottom: 16,
  },
  cardTitle: {
    fontSize:     11,
    fontWeight:   800,
    color:        "#64748b",
    textTransform: "uppercase" as const,
    letterSpacing: "0.08em",
    marginBottom: 16,
    marginTop:    0,
  },
  agentRow: {
    display:        "flex",
    justifyContent: "space-between",
    alignItems:     "flex-start",
    padding:        "8px 0",
    borderBottom:   "1px solid rgba(255,255,255,0.04)",
  },
  agentLeft: {
    display:    "flex",
    alignItems: "flex-start",
    gap:        10,
  },
  agentRight: {
    textAlign: "right" as const,
  },
  agentName: {
    fontSize:   13,
    fontWeight: 700,
    color:      "#e2e8f0",
  },
  agentMeta: {
    fontSize: 10,
    color:    "#64748b",
    marginTop: 2,
  },
  agentCount: {
    fontSize:   12,
    fontWeight: 700,
    color:      "#94a3b8",
  },
  statusDot: {
    width:        8,
    height:       8,
    borderRadius: "50%",
    flexShrink:   0,
    marginTop:    4,
  },
  barLabel: {
    fontSize:   11,
    fontWeight: 600,
    color:      "#cbd5e1",
  },
  barBg: {
    background:   "rgba(255,255,255,0.05)",
    borderRadius: 2,
    height:       4,
    overflow:     "hidden",
  },
  barFill: {
    background:   "rgba(148,163,184,0.4)",
    borderRadius: 2,
    height:       "100%",
    transition:   "width 0.3s ease",
  },
  signalRow: {
    display:        "flex",
    justifyContent: "space-between",
    alignItems:     "flex-start",
    padding:        "6px 0",
    borderBottom:   "1px solid rgba(255,255,255,0.04)",
  },
  signalLeft: {
    display:    "flex",
    alignItems: "flex-start",
    gap:        8,
    flex:       1,
    minWidth:   0,
  },
  signalRight: {
    textAlign:  "right" as const,
    flexShrink: 0,
    marginLeft: 12,
  },
  signalAgent: {
    fontSize:   11,
    fontWeight: 700,
    color:      "#e2e8f0",
  },
  signalAction: {
    color:      "#94a3b8",
    fontWeight: 400,
  },
  signalSubject: {
    color:      "#64748b",
    fontWeight: 400,
  },
  signalResult: {
    fontSize:    10,
    color:       "#64748b",
    marginTop:   2,
    maxWidth:    420,
    overflow:    "hidden",
    textOverflow: "ellipsis",
    whiteSpace:  "nowrap",
  },
  signalMeta: {
    fontSize: 10,
    color:    "#475569",
    lineHeight: 1.6,
  },
  confidenceDot: {
    width:        6,
    height:       6,
    borderRadius: "50%",
    flexShrink:   0,
    marginTop:    4,
  },
  errorBox: {
    background:   "rgba(239,68,68,0.08)",
    border:       "1px solid rgba(239,68,68,0.2)",
    borderRadius: 8,
    padding:      "16px 20px",
    fontSize:     13,
    color:        "#cbd5e1",
    display:      "flex",
    alignItems:   "center",
    gap:          12,
  },
  retryBtn: {
    background:   "rgba(239,68,68,0.15)",
    border:       "1px solid rgba(239,68,68,0.3)",
    color:        "#fca5a5",
    borderRadius: 6,
    padding:      "4px 12px",
    cursor:       "pointer",
    fontSize:     12,
    marginLeft:   "auto",
  },
  emptyNote: {
    fontSize: 12,
    color:    "#475569",
    margin:   0,
  },
  skeletonGrid: {
    display:             "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap:                 16,
  },
  skeleton: {
    background:   "rgba(255,255,255,0.04)",
    borderRadius: 12,
    height:       80,
    animation:    "pulse 1.5s infinite",
  },
};
