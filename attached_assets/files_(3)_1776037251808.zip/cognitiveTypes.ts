// server/operator/cognitiveTypes.ts
// Modified: added "apex_learning" to EpisodicMemoryType, ApexInsight interface,
//           and apexInsights field to ContextPacket.

export type MemoryType = "session" | "workspace" | "behavior" | "performance" | "pattern";

// "apex_learning" added here — TypeScript-only extension.
// The agentMemories table uses a text() column, so no DB migration is required.
export type EpisodicMemoryType = "decision" | "outcome" | "preference" | "observation" | "apex_learning";

export interface EpisodicMemory {
  id?: number;
  subAccountId: number;
  memoryType: EpisodicMemoryType;
  content: string;
  category?: string;
  relevanceScore: number;
  decayRate: number;
  sourceEvent?: string;
  sourceContext?: Record<string, unknown>;
  outcome?: string;
  tags?: string[];
  accessCount?: number;
  lastAccessedAt?: string;
  createdAt?: string;
}

export interface MemoryEntry {
  id?: number;
  subAccountId: number;
  memoryType: MemoryType;
  key: string;
  value: any;
  confidence: number;
  source: string;
  version: number;
  createdAt?: string;
  updatedAt?: string;
  expiresAt?: string;
}

export interface WorkspaceProfile {
  industry: string;
  businessName: string;
  location?: string;
  targetMarket?: string;
  services?: string[];
  leadSources?: string[];
  pricingModel?: string;
  phoneConfigured: boolean;
  integrationCount: number;
  automationCount: number;
  contactCount: number;
  siteCount: number;
}

export interface UserBehaviorProfile {
  recommendationAcceptRate: number;
  avgResponseTimeMs: number;
  preferredStyle: "analytical" | "action" | "skeptical" | "balanced";
  complexityTolerance: "low" | "medium" | "high";
  ignoreCount: number;
  acceptCount: number;
  lastInteraction: string;
  nudgesShown: number;
  nudgesDismissed: number;
}

export interface PerformanceSnapshot {
  subAccountId: number;
  contactCount: number;
  messageCount: number;
  inboundMessages: number;
  outboundMessages: number;
  failedMessages: number;
  automationCount: number;
  activeAutomations: number;
  avgResponseTimeSec?: number;
  leadConversionRate?: number;
  timestamp: string;
}

export interface PatternInsight {
  pattern: string;
  confidence: number;
  dataPoints: number;
  firstSeen: string;
  lastSeen: string;
  category: "conversion" | "timing" | "channel" | "engagement" | "system";
}

export interface AdvisoryInsight {
  id: string;
  subAccountId: number;
  category: "opportunity" | "warning" | "optimization" | "milestone";
  title: string;
  message: string;
  dataBacking: Record<string, any>;
  confidence: number;
  priority: number;
  actionable: boolean;
  suggestedTool?: string;
  suggestedParams?: Record<string, any>;
  expiresAt?: string;
}

export interface NudgeConfig {
  maxPerDay: number;
  minIntervalMs: number;
  respectDismissals: boolean;
  maxConsecutiveIgnores: number;
}

// ---------------------------------------------------------------------------
// NEW: Apex Intelligence insight — cross-agent pattern detected by the learning loop
// Defined here (not in apexIntelligence.ts) to avoid a circular import chain.
// apexIntelligence.ts imports this type from here.
// ---------------------------------------------------------------------------
export interface ApexInsight {
  pattern:        string;        // human-readable pattern description e.g. "sentinel:incident_detected → layla:send"
  agentsInvolved: string[];      // e.g. ["sentinel", "layla"]
  confidence:     number;        // 0–1
  occurrences:    number;        // how many times this pattern was observed
  lastSeen:       string;        // ISO timestamp
  scope:          "account" | "global";
}

export interface ContextPacket {
  workspace: WorkspaceProfile;
  behavior: UserBehaviorProfile;
  performance: PerformanceSnapshot;
  patterns: PatternInsight[];
  recentEvents: Array<{ type: string; at: string; payload: any }>;
  activeNudges: number;
  diagnosticsSummary: string;
  industryKnowledge?: IndustryKnowledge;
  pastExperiences?: EpisodicMemory[];
  crossAccountBenchmarks?: Record<string, {
    avg: number;
    median: number;
    p25: number;
    p75: number;
    p90: number;
    sampleSize: number;
    unit: string;
  }>;
  sharedInsights?: Array<{ category: string; content: string }>;
  // NEW: cross-agent intelligence patterns — populated by apexIntelligence layer
  // Optional — contextBuilder populates this when apex module is available.
  // Never exposes cross-account data; always account-scoped.
  apexInsights?: ApexInsight[];
}

export interface IndustryKnowledge {
  industry: string;
  leadStrategies: string[];
  conversionBenchmarks: Record<string, number>;
  bestChannels: string[];
  seasonalTrends?: string[];
  commonWorkflows: string[];
  avgResponseTimeBenchmark: number;
  tips: string[];
}
