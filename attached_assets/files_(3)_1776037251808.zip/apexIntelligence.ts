/**
 * server/operator/apexIntelligence.ts
 *
 * Apex Intelligence Orchestrator — central hub.
 *
 * Responsibilities:
 *   - Maintain agent registry (in-memory)
 *   - Accept outcome reports from all agents via reportOutcome()
 *   - Expose admin-only unified state via getApexState()
 *   - Provide account-scoped insight enrichment via getApexInsightsForAccount()
 *
 * MULTI-TENANT SAFETY:
 *   - getApexState()               → admin only, never expose to customer routes
 *   - getApexInsightsForAccount()  → account-scoped, safe for contextBuilder
 *   - reportOutcome() with null subAccountId  → global/system signal
 *   - reportOutcome() with a subAccountId     → account-scoped signal
 *
 * FAILURE MODE:
 *   - reportOutcome() never throws — failures are logged and swallowed
 *   - getApexInsightsForAccount() returns [] on failure
 */

import { reportSignal, getRecentSignals, getSignalStats } from "./intelligenceAggregator";
import type { ApexInsight } from "./cognitiveTypes";

// ---------------------------------------------------------------------------
// Agent registry
// ---------------------------------------------------------------------------

export interface AgentRegistration {
  name:           string;
  capabilities:   string[];
  outputSchema:   string;   // human-readable description of what this agent reports
  registeredAt:   string;
  lastReportedAt: string | null;
  totalReports:   number;
  status:         "active" | "idle" | "error";
  lastError?:     string;
}

const agentRegistry = new Map<string, AgentRegistration>();

export function registerAgent(
  name:         string,
  capabilities: string[],
  outputSchema: string,
): void {
  agentRegistry.set(name, {
    name,
    capabilities,
    outputSchema,
    registeredAt:   new Date().toISOString(),
    lastReportedAt: null,
    totalReports:   0,
    status:         "active",
  });
  console.log(`[APEX] Agent registered: ${name} (${capabilities.length} capabilities)`);
}

// ---------------------------------------------------------------------------
// Outcome reporting — single entry point for all contributing agents
// ---------------------------------------------------------------------------

export interface OutcomeReport {
  agentName:    string;
  action:       string;
  subject?:     string;
  result:       string;
  confidence?:  number;
  subAccountId?: number | null;  // null or omitted = global/system-level signal
  metadata?:    Record<string, any>;
}

export async function reportOutcome(report: OutcomeReport): Promise<void> {
  // Update registry health metadata
  const reg = agentRegistry.get(report.agentName);
  if (reg) {
    reg.lastReportedAt = new Date().toISOString();
    reg.totalReports++;
    reg.status = "active";
    agentRegistry.set(report.agentName, reg);
  }

  try {
    await reportSignal({
      agentName:    report.agentName,
      action:       report.action,
      subject:      report.subject ?? null,
      result:       report.result,
      confidence:   report.confidence ?? 0.5,
      subAccountId: report.subAccountId ?? null,
      metadata:     report.metadata ?? null,
    });
  } catch (err: any) {
    // Mark agent error state but never throw — callers must not be impacted
    if (reg) {
      reg.status    = "error";
      reg.lastError = String(err?.message ?? "unknown").substring(0, 200);
      agentRegistry.set(report.agentName, reg);
    }
    console.error(
      `[APEX] reportOutcome failed for agent "${report.agentName}": ${err?.message}`
    );
  }
}

// ---------------------------------------------------------------------------
// Unified state — for admin endpoint ONLY
// Never expose to customer-facing routes.
// ---------------------------------------------------------------------------

export interface ApexState {
  registry:      AgentRegistration[];
  signalStats:   Awaited<ReturnType<typeof getSignalStats>>;
  recentSignals: Awaited<ReturnType<typeof getRecentSignals>>;
  generatedAt:   string;
}

export async function getApexState(): Promise<ApexState> {
  const [signalStats, recentSignals] = await Promise.all([
    getSignalStats(),
    getRecentSignals({
      limit: 50,
      since: new Date(Date.now() - 24 * 60 * 60 * 1000),
    }),
  ]);

  return {
    registry:      Array.from(agentRegistry.values()),
    signalStats,
    recentSignals,
    generatedAt:   new Date().toISOString(),
  };
}

// ---------------------------------------------------------------------------
// Account-scoped insight enrichment — safe to pass into contextBuilder
// Returns only signals for the specified account. Never returns other accounts' data.
// ---------------------------------------------------------------------------

export async function getApexInsightsForAccount(
  subAccountId: number,
): Promise<ApexInsight[]> {
  try {
    const signals = await getRecentSignals({
      subAccountId,
      since: new Date(Date.now() - 72 * 60 * 60 * 1000),
      limit: 200,
    });

    if (signals.length < 2) return [];

    // Lightweight co-occurrence detection: cross-agent action pairs within 30 min
    const pairCounts = new Map<string, {
      count:      number;
      agents:     Set<string>;
      lastSeen:   string;
      confidence: number;
    }>();

    for (let i = 0; i < signals.length; i++) {
      // Only look at the next 5 signals — keeps this O(n * 5) = O(n)
      for (let j = i + 1; j < Math.min(signals.length, i + 6); j++) {
        const a = signals[i];
        const b = signals[j];

        if (a.agentName === b.agentName) continue; // cross-agent only

        const timeDiffMs = Math.abs(
          new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
        );
        if (timeDiffMs > 30 * 60 * 1000) continue;

        const key      = `${a.agentName}:${a.action} → ${b.agentName}:${b.action}`;
        const existing = pairCounts.get(key) ?? {
          count:      0,
          agents:     new Set<string>(),
          lastSeen:   a.createdAt,
          confidence: 0,
        };

        existing.count++;
        existing.agents.add(a.agentName);
        existing.agents.add(b.agentName);
        // Rolling average of signal confidence
        existing.confidence =
          (existing.confidence * (existing.count - 1) +
            (a.confidence + b.confidence) / 2) /
          existing.count;
        if (a.createdAt > existing.lastSeen) existing.lastSeen = a.createdAt;
        pairCounts.set(key, existing);
      }
    }

    return Array.from(pairCounts.entries())
      .filter(([_, v]) => v.count >= 2)
      .sort((a, b) => b[1].count - a[1].count)
      .slice(0, 5)
      .map(([pattern, v]) => ({
        pattern,
        agentsInvolved: Array.from(v.agents),
        confidence:     Math.min(0.95, v.confidence),
        occurrences:    v.count,
        lastSeen:       v.lastSeen,
        scope:          "account" as const,
      }));
  } catch (err: any) {
    console.error(
      `[APEX] getApexInsightsForAccount failed for account ${subAccountId}:`,
      err?.message,
    );
    return [];
  }
}
