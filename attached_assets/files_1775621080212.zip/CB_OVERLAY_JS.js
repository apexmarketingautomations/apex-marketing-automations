// RoomOS Live Billboard — JS Tab
// Paste this entire file into the JS tab. No <script> tags needed.

var NSLIDES = 7;
var SDUR    = 10000; // 10 seconds per slide
var HDUR    = 5000;  // 5 seconds per hook

var total = 0, goals = 0, tipCount = 0, goal = 500;
var flashTimer = null, slideTimer = null;
var tipIdx = 0, aiIdx = 0, hookIdx = 0;

var SLIDE_COLORS = ['#CC1122','#2244EE','#5533CC','#2244EE','#CC1122','#5533CC','#2244EE'];

var HOOKS = [
  { eyes:'👀👀👀👀', l1:'HEY <em>YOU.</em>',                            l2:"This isn't a normal room.<br>Watch what happens next.", color:'#CC1122' },
  { eyes:'👀👀👀👀', l1:'THIS ROOM IS DOING<br><em>SOMETHING DIFFERENT.</em>', l2:'Watch closely.',                                     color:'#2244EE' },
  { eyes:'👀👀👀👀', l1:'STOP <em>SCROLLING.</em>',                     l2:'This is what an upgraded room looks like.',             color:'#5533CC' },
  { eyes:'👀👀👀👀', l1:'IF YOUR ROOM FEELS<br><em>DEAD RIGHT NOW…</em>',l2:'You need to see this.',                                color:'#CC1122' },
  { eyes:'👀👀👀👀', l1:'THIS IS NOT<br>JUST A <em>ROOM.</em>',         l2:'It is a live system. Watch.',                           color:'#2244EE' }
];

var TIPS = [
  { u:'wendy_N_alex1712', a:150, m:'this system is insane',      big:false },
  { u:'blazeit420xx',      a:500, m:'take it all',                big:true  },
  { u:'n877',              a:301, m:'VIP every time',             big:true  },
  { u:'kingdomcvme',       a:200, m:'RoomOS is the real deal',    big:false },
  { u:'raymy23',           a:100, m:"let's gooo",                 big:false },
  { u:'silentwhale77',     a:250, m:'worth every token',          big:false },
  { u:'loverboy_99x',      a:75,  m:'best setup I seen',          big:false },
  { u:'apex_fan_2026',     a:100, m:'Apex is built different',    big:false },
];

var AI_SUGS = [
  '"<strong>wendy_N_alex1712</strong> just entered — 850 lifetime tokens. Say something personal."',
  '"Room cooling. 4 min since last tip. Fire a <strong>near-goal push</strong> now."',
  '"<strong>blazeit420xx</strong> is watching. 500 tokens tonight. Call them out."',
  '"32 tokens from goal. This is the <strong>highest-converting moment</strong>. Push now."',
  '"90 seconds of silence. Break the pattern before you lose the room."',
];

var AI_CTX = [
  { e:'Cooling', r:'125 tkns', s:'4 min'  },
  { e:'Hot',     r:'32 tkns',  s:'45 sec' },
  { e:'Warming', r:'200 tkns', s:'2 min'  },
  { e:'Dead',    r:'380 tkns', s:'8 min'  },
  { e:'Cooling', r:'90 tkns',  s:'90 sec' },
];

function el(id) { return document.getElementById(id); }

function updateStats(t) {
  total += t.a;
  tipCount++;
  var prog = total % goal;
  if (prog < t.a && total > t.a) goals++;
  var pct = Math.min(100, Math.round(prog / goal * 100));

  el('d-ses').textContent = total.toLocaleString();
  el('d-gls').textContent = goals;
  el('d-tps').textContent = tipCount;
  el('d-gt').textContent  = 'Goal: ' + prog + ' / ' + goal;
  el('d-pct').textContent = pct + '%';
  el('d-fill').style.width = pct + '%';

  el('r-tok').textContent  = total.toLocaleString();
  el('r-gls').textContent  = goals;
  el('r-tps').textContent  = tipCount;
  el('r-pct').textContent  = pct + '%';
  el('r-fill').style.width = pct + '%';

  el('a-tok').textContent = total.toLocaleString();
  el('a-gls').textContent = goals;
  el('a-tps').textContent = tipCount;
}

function fireTip() {
  var t  = TIPS[tipIdx % TIPS.length];
  updateStats(t);
  if (flashTimer) clearTimeout(flashTimer);

  var f  = el('d-flash');
  var fb = el('d-fbar');

  el('d-fu').textContent = t.u;
  el('d-fm').textContent = t.m;
  el('d-fa').textContent = '+' + t.a;

  f.className = 'tcard ' + (t.big ? 'big' : 'nrm') + ' show';
  fb.style.animation = 'none';
  void fb.offsetWidth;
  fb.style.animation = 'drain ' + (t.big ? 6 : 4) + 's linear forwards';
  f.style.animation  = 'none';
  void f.offsetWidth;
  f.style.animation  = 'cardIn 0.4s cubic-bezier(0.34,1.56,0.64,1) both';

  flashTimer = setTimeout(function() {
    f.classList.remove('show');
  }, t.big ? 6000 : 4000);

  tipIdx++;
}

function rotateAI() {
  var c   = AI_SUGS[aiIdx % AI_SUGS.length];
  var ctx = AI_CTX[aiIdx  % AI_CTX.length];
  el('ai-text').innerHTML  = c;
  el('ai-e').textContent   = ctx.e;
  el('ai-r').textContent   = ctx.r;
  el('ai-s').textContent   = ctx.s;
  aiIdx++;
}

function clearSlides() {
  for (var i = 0; i < NSLIDES; i++) {
    var s   = document.getElementById('s' + (i + 1));
    var ind = document.getElementById('i' + i);
    if (s)   s.classList.remove('on');
    if (ind) {
      ind.classList.remove('on');
      var p = ind.querySelector('.indp');
      if (p) p.style.animation = 'none';
    }
  }
}

function goToSlide(n) {
  clearSlides();

  var s = document.getElementById('s' + (n + 1));
  if (s) {
    s.querySelectorAll('.ey,.sh,.ss,.lp,.tcard,.phone-outer,.wlist,.ai-wrap,.rg,.rprog,.cta-wrap,.adash').forEach(function(e) {
      var c = e.cloneNode(true);
      e.parentNode.replaceChild(c, e);
    });
    s.classList.add('on');
  }

  var color = SLIDE_COLORS[n] || '#4466FF';
  var ind   = document.getElementById('i' + n);
  if (ind) {
    ind.classList.add('on');
    ind.style.background = color + '22';
    var p = ind.querySelector('.indp');
    if (p) {
      p.style.background = color;
      p.style.animation  = 'none';
      void p.offsetWidth;
      p.style.animation  = 'indFill 10s linear forwards';
    }
  }

  var pill  = el('lpill');
  var badge = el('tbadge');
  if (pill)  { pill.style.borderColor = color + '66'; pill.style.color = color; }
  if (badge) badge.style.color = color;
}

function showHook(h, onDone) {
  clearSlides();
  el('heyes').textContent = h.eyes;
  el('hl1').innerHTML     = h.l1;
  el('hl2').innerHTML     = h.l2;

  var hbar = el('hbar');
  if (hbar) hbar.style.background = h.color;

  el('hl1').querySelectorAll('em').forEach(function(e) {
    e.style.color = h.color;
  });

  var hel = el('hook');
  hel.style.transition = 'none';
  hel.style.opacity    = '0';
  hel.classList.add('on');
  void hel.offsetWidth;
  hel.style.transition = 'opacity 0.7s ease';
  hel.style.opacity    = '1';

  setTimeout(function() {
    hel.style.opacity = '0';
    setTimeout(function() {
      hel.classList.remove('on');
      hel.style.opacity    = '';
      hel.style.transition = '';
      if (onDone) onDone();
    }, 700);
  }, HDUR);
}

function runCycle(hookData, onComplete) {
  showHook(hookData, function() {
    var s = 0;
    goToSlide(s);
    slideTimer = setInterval(function() {
      s++;
      if (s >= NSLIDES) {
        clearInterval(slideTimer);
        slideTimer = null;
        if (onComplete) onComplete();
      } else {
        goToSlide(s);
      }
    }, SDUR);
  });
}

function startLoop() {
  var h = HOOKS[hookIdx % HOOKS.length];
  hookIdx++;
  runCycle(h, function() {
    setTimeout(startLoop, 150);
  });
}

// Boot
fireTip();
setInterval(fireTip,   4000);
setInterval(rotateAI, 10000);
setTimeout(startLoop,   100);
