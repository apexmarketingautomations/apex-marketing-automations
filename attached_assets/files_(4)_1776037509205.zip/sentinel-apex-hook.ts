/**
 * Apex Intelligence hook for server/sentinel.ts
 *
 * Drop this import at the top of the file (if not already using dynamic import):
 *   No static import needed — uses dynamic import to avoid circular deps.
 *
 * Drop reportSentinelOutcome() call immediately after createSentinelIncident()
 * returns a record, inside both the Home Services and Accident scan branches.
 */

// ---------------------------------------------------------------------------
// Paste this function near the top of sentinel.ts, after existing imports.
// It is self-contained and fail-closed.
// ---------------------------------------------------------------------------

async function reportSentinelOutcome(
  record: {
    id:           number;
    subAccountId: number;
    severity:     string | null;
    title:        string | null;
    location:     string | null;
  },
  niche:    string,
  signalType?: string,
): Promise<void> {
  try {
    const { reportOutcome } = await import("./operator/apexIntelligence");
    await reportOutcome({
      agentName:    "sentinel",
      action:       niche === "home_services" ? "incident_detected" : "accident_detected",
      subject:      signalType ?? (niche === "home_services" ? "weather_signal" : "vehicle_crash"),
      result:       `${record.severity ?? "medium"} incident: ${record.title ?? "unknown"}`,
      confidence:   record.severity === "critical" ? 0.95
                  : record.severity === "high"     ? 0.80
                  : 0.65,
      subAccountId: record.subAccountId,
      metadata: {
        incidentId: record.id,
        niche,
        severity:   record.severity,
        location:   record.location,
      },
    });
  } catch {
    // Never crash sentinel — apex reporting is non-critical
  }
}


// ---------------------------------------------------------------------------
// Call site — Home Services scan branch
// Add AFTER: created.push(record);
// ---------------------------------------------------------------------------

/*
    reportSentinelOutcome(
      record,
      "home_services",
      (sig as any).signalType,
    ).catch(() => {});
*/


// ---------------------------------------------------------------------------
// Call site — Accident scan branch
// Add AFTER: the createSentinelIncident call that returns a record
// ---------------------------------------------------------------------------

/*
    reportSentinelOutcome(
      record,
      "accident",
    ).catch(() => {});
*/
