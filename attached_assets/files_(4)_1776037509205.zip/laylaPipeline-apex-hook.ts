/**
 * Apex Intelligence hook for server/services/personas/laylaPipeline.ts
 *
 * Drop reportLaylaOutcome() near the top of the file.
 * Call it at the point where Layla resolves a final action.
 *
 * Relative import path: adjust based on actual file depth.
 *   From server/services/personas/ → "../../../operator/apexIntelligence"
 *   From server/services/         → "../../operator/apexIntelligence"
 *   From server/                  → "./operator/apexIntelligence"
 */

// ---------------------------------------------------------------------------
// Paste this function near the top of laylaPipeline.ts
// ---------------------------------------------------------------------------

async function reportLaylaOutcome(
  action:       string,        // "send" | "handover" | "qualify" | "respond" | etc.
  subAccountId: number,
  meta: {
    contactId?:      number | string | null;
    conversationId?: number | string | null;
    confidence?:     number;
    outcome?:        string;
  } = {},
): Promise<void> {
  try {
    const { reportOutcome } = await import("../../../operator/apexIntelligence");
    await reportOutcome({
      agentName:    "layla",
      action,
      subject:      "conversation",
      result:       `Layla action: ${action}${meta.outcome ? ` → ${meta.outcome}` : ""}`,
      confidence:   meta.confidence ?? 0.75,
      subAccountId,
      metadata: {
        actionType:     action,
        contactId:      meta.contactId      ?? null,
        conversationId: meta.conversationId ?? null,
        outcome:        meta.outcome        ?? null,
      },
    });
  } catch {
    // Never crash the Layla pipeline — apex reporting is non-critical
  }
}


// ---------------------------------------------------------------------------
// Call site — after Layla resolves its action (send, handover, qualify, etc.)
// Place at the point where the pipeline returns or resolves the final action.
// ---------------------------------------------------------------------------

/*
    reportLaylaOutcome(
      actionType,         // the action Layla decided on
      subAccountId,
      {
        contactId,
        conversationId,
        confidence: actionConfidence,
        outcome:    actionResult,
      },
    ).catch(() => {});
*/


// ---------------------------------------------------------------------------
// If Layla handles multiple action types in a switch/if-else,
// a single call after the switch resolves is cleaner than one per branch.
// If each branch has its own async resolution, call it inside each branch.
// ---------------------------------------------------------------------------
