/**
 * Additions for client/src/pages/intelligence-dashboard.tsx
 *
 * Three insertions required. Each is clearly labeled.
 * Nothing else in the file changes.
 */


// ---------------------------------------------------------------------------
// INSERTION 1 — Add to imports at the top of the file
// ---------------------------------------------------------------------------

import { ApexBrainTab } from "../components/intelligence/ApexBrainTab";


// ---------------------------------------------------------------------------
// INSERTION 2 — Add to the tab definitions array
//
// Find where other tabs are defined. The array probably looks like:
//
//   const tabs = [
//     { id: "overview", label: "Overview" },
//     { id: "agents",   label: "Agents"   },
//     ...
//   ];
//
// Add this entry at the end:
// ---------------------------------------------------------------------------

{ id: "apex", label: "⬡ Apex Brain" },


// ---------------------------------------------------------------------------
// INSERTION 3 — Add to the tab content render section
//
// Find where other tabs render their content. Probably looks like:
//
//   {activeTab === "overview" && <OverviewTab />}
//   {activeTab === "agents"   && <AgentTab />}
//   ...
//
// Add this after the last existing tab render:
// ---------------------------------------------------------------------------

{activeTab === "apex" && <ApexBrainTab />}


// ---------------------------------------------------------------------------
// NOTES
// ---------------------------------------------------------------------------
//
// - "activeTab" is whatever the real state variable is called.
//   Match it to the existing tab state in the file.
//
// - "apex" must match the id in INSERTION 2 exactly.
//
// - ApexBrainTab fetches /api/intelligence/apex on mount.
//   It expects an x-admin-secret header. Set window.__ADMIN_SECRET__
//   or localStorage.adminSecret in the admin session before opening
//   this tab, or wire the admin secret into the fetch call directly
//   if the dashboard already has a mechanism for admin credentials.
//
// - The tab will show a "Forbidden" error state if the admin secret
//   is not present — this is correct behavior, not a bug.
