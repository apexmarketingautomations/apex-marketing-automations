/**
 * Apex Intelligence hook for server/crashIngestPipeline.ts
 *
 * Drop reportCrashOutcome() near the top of the file.
 * Call it at two points: after crash ingestion, and after lead creation.
 */

// ---------------------------------------------------------------------------
// Paste this function near the top of crashIngestPipeline.ts
// ---------------------------------------------------------------------------

async function reportCrashOutcome(
  action:       "crash_ingested" | "lead_created",
  subAccountId: number,
  ids: {
    incidentId?: number | string | null;
    leadId?:     number | string | null;
    crashId?:    number | string | null;
  } = {},
): Promise<void> {
  try {
    const { reportOutcome } = await import("./operator/apexIntelligence");
    await reportOutcome({
      agentName:    "crash-ingest",
      action,
      subject:      "vehicle_crash",
      result:       action === "lead_created"
                      ? `Lead created from crash ingest (lead #${ids.leadId ?? "unknown"})`
                      : `Crash ingested for account ${subAccountId}`,
      confidence:   action === "lead_created" ? 0.92 : 0.85,
      subAccountId,
      metadata: {
        incidentId: ids.incidentId ?? null,
        leadId:     ids.leadId     ?? null,
        crashId:    ids.crashId    ?? null,
      },
    });
  } catch {
    // Never crash the ingest pipeline — apex reporting is non-critical
  }
}


// ---------------------------------------------------------------------------
// Call site 1 — after a crash record is successfully created/upserted
// ---------------------------------------------------------------------------

/*
    reportCrashOutcome("crash_ingested", subAccountId, { incidentId: incident.id }).catch(() => {});
*/


// ---------------------------------------------------------------------------
// Call site 2 — after a lead is successfully created from the crash
// ---------------------------------------------------------------------------

/*
    reportCrashOutcome("lead_created", subAccountId, {
      incidentId: incident.id,
      leadId:     lead.id,
    }).catch(() => {});
*/
