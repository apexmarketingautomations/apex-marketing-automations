/**
 * Additions for client/src/components/intelligence/AgentTab.tsx
 *
 * Adds a cross-reference link to the Apex Brain tab at the bottom
 * of the agent list. One prop addition, one render addition.
 */


// ---------------------------------------------------------------------------
// INSERTION 1 — Add onTabChange to the component's props interface
//
// Find the existing Props interface or props destructure. Add:
// ---------------------------------------------------------------------------

// If there is an existing interface:
interface AgentTabProps {
  // ... existing props ...
  onTabChange?: (tabId: string) => void;   // ADD THIS
}

// If props are destructured inline:
// ({ existingProp1, existingProp2, onTabChange }: AgentTabProps)


// ---------------------------------------------------------------------------
// INSERTION 2 — Add cross-reference UI at the bottom of the component's
// return statement, just before the final closing tag.
//
// Find the last visible element in the return and add below it:
// ---------------------------------------------------------------------------

<div
  style={{
    marginTop:    24,
    paddingTop:   16,
    borderTop:    "1px solid rgba(255,255,255,0.06)",
    display:      "flex",
    alignItems:   "center",
    justifyContent: "space-between",
  }}
>
  <span style={{ fontSize: 11, color: "#475569" }}>
    Cross-agent patterns are available in Apex Brain
  </span>
  <button
    onClick={() => onTabChange?.("apex")}
    style={{
      background:   "rgba(255,255,255,0.04)",
      border:       "1px solid rgba(255,255,255,0.08)",
      color:        "#94a3b8",
      fontSize:     11,
      fontWeight:   600,
      cursor:       "pointer",
      padding:      "5px 12px",
      borderRadius: 6,
      transition:   "background 0.15s",
    }}
    onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.08)")}
    onMouseLeave={e => (e.currentTarget.style.background = "rgba(255,255,255,0.04)")}
  >
    ⬡ View Apex Brain →
  </button>
</div>


// ---------------------------------------------------------------------------
// INSERTION 3 — Pass onTabChange from the parent dashboard
//
// In intelligence-dashboard.tsx, find where <AgentTab /> is rendered.
// Add the onTabChange prop:
// ---------------------------------------------------------------------------

<AgentTab
  onTabChange={(tabId) => setActiveTab(tabId)}
  // ... existing props ...
/>

// Replace setActiveTab with whatever the dashboard uses to change tabs.
